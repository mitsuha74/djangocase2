from django.template import Library
from django.conf import settings
import copy
register = Library()

@register.inclusion_tag('meun.html')
def unicom_meun(request):
    role = request.unicom_role
    user_meun_list = copy.deepcopy(settings.UNICOM_MEUN[role])
    for row in user_meun_list:
        if request.path_info.startswith(row['url']):
            row['class']='active'
    return {'meun_list':user_meun_list}
