from django.shortcuts import render,redirect

def order(request):

    return render(request,'order.html')

def order_add(request):

    return redirect('order_add.html')
