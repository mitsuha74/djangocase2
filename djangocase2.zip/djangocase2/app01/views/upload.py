from django.shortcuts import render,redirect,HttpResponse
import os
from django import forms
from app01 import models
def up(request):
    if request.method == 'GET':
        return render(request,'up.html')
    obj = request.FILES.get('fs')
    file_path = os.path.join('media',obj.name)
    with open(file_path,'wb') as f:
        for chunk in obj.chunks():
            f.write(chunk)
    return HttpResponse("成功")

class UpModelForm(forms.ModelForm):
    class Meta:
        model = models.Info
        fields = '__all__'

def up_form(request):
    if request.method == 'GET':
        form = UpModelForm()
        return render(request,'up_form.html',{'form':form})
    form = UpModelForm(data=request.POST,files=request.FILES)
    if not form.is_valid():
        return render(request,'up_form.html',{'form':form})
    form.save()
    return HttpResponse("成功")
