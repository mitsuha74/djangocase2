from django.shortcuts import render,redirect
from app01 import models
from utils.pagination import Pagination
from utils.bootstrap import BootstrapModelForm
from django.http import JsonResponse

class MyModelForm(BootstrapModelForm):
    class Meta:
        model = models.Order
        fields = ['tpl',]

def my(request):
    form = MyModelForm()
    queryset = models.Order.objects.filter(leader=request.unicom_userid)
    page = Pagination(request,queryset.count())
    queryset = queryset[page.start:page.end]
    context = {
        'queryset':queryset,
        'page_string':page.html(),
        'form':form
    }
    return render(request,'my.html',context)

from datetime import datetime
def my_add(request):
    form = MyModelForm(request.POST)
    if not form.is_valid():
        return JsonResponse({'status':False,'error':form.errors})
    tpl_obj = form.cleaned_data['tpl']
    form.instance.user_id = request.unicom_userid
    form.instance.leader_id = tpl_obj.leader_id
    form.instance.create_deletime = datetime.now()
    form.save()
    return JsonResponse({'status':True})
