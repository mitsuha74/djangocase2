from django.shortcuts import render, redirect
from app01 import models
from utils.pagination import Pagination

def work(request):
    return render(request, 'work.html')
