from django.shortcuts import render, redirect


def user(request):
    return render(request, 'user.html')
