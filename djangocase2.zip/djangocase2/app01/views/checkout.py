from django.shortcuts import render,redirect,HttpResponse
from app01 import models
from utils.pagination import Pagination

def checkout(request):
    nocheck = models.Order.objects.filter(status=1,leader_id=request.unicom_userid).count()
    queryset = models.Order.objects.filter(leader_id=request.unicom_userid)
    page = Pagination(request,queryset.count())
    queryset = queryset[page.start:page.end]

    context = {
        'queryset':queryset,
        'page_string':page.html(),
        'nocheck':nocheck
    }
    return render(request,'checkout.html',context)

def checkout_up(request,action,oid):
    if not action in {1,2,}:
        return HttpResponse("请求错误")
    from datetime import datetime
    if action==1:
        models.Order.objects.filter(id=oid,status=1,leader_id=request.unicom_userid).update(status=2,update_deletime=datetime.now())
    else:
        models.Order.objects.filter(id=oid, status=1,leader_id=request.unicom_userid).update(status=3,update_deletime=datetime.now())
    return redirect('/checkout/')
