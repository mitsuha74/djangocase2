from django.shortcuts import render,redirect
from django import forms
from app01 import models

class LoginForm(forms.Form):
    username = forms.CharField(label='用户名',required=True)
    password = forms.CharField(label='密码',required=True,widget=forms.PasswordInput(render_value=True))

    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        for name,field in self.fields.items():
            field.widget.attrs['class'] = 'form-control'
            field.widget.attrs['placeholder'] = '请输入{}'.format(field.label)


def login(request):
    if request.method == "GET":
        form = LoginForm()
        # print(form)
        return render(request,'login.html',{'form':form})
    form = LoginForm(data=request.POST)
    if not form.is_valid():
        # print(form)
        return render(request,'login.html',{'form':form})
    user_obj = models.UserInfo.objects.filter(**form.cleaned_data).first()
    # print(user_obj)
    if not user_obj:
        return render(request,'login.html',{'form':form,'error':'用户名或者密码错误'})

    request.session['user_info']={'id':user_obj.id,'username':user_obj.username,'role':user_obj.role}
    return redirect('/home/')

def logout(request):
    request.session.clear()
    return redirect('/login/')

def home(request):
    return render(request,'home.html')
