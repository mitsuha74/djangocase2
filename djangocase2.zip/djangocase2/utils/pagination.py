import copy
from django.utils.safestring import mark_safe
class Pagination(object):
    def __init__(self,request,total_count):
        page = request.GET.get('page','1')
        if not page.isdecimal():
            page = 1
        else:
            page = int(page)
            if page<1:
                page = 1
        self.page = page
        self.start = (page-1)*10
        self.end = page*10
        self.total_count = total_count
        total_page,div = divmod(self.total_count,10)
        if div:
            total_page += 1
        self.total_page = total_page

        self.quert_dict = copy.deepcopy(request.GET)
        self.quert_dict._mutable=True


    def html(self):
        page_list = []
        if self.total_page<=11:
            page_start = 1
            page_end = self.total_page
        else:
            if self.page<=5:
                page_start = 1
                page_end = 11+1
            else:
                if self.page+5>self.total_page:
                    page_start = self.total_page-9
                    page_end = self.total_page+1
                else:
                    page_start = self.page-5
                    page_end = self.page+5
        for i in range(page_start,page_end+1):
            self.quert_dict.setlist('page',[i])
            query = self.quert_dict.urlencode()
            if i == self.page:
                element = '<li class="active"><a href="?{}">{}</a><li>'.format(query, i)
            else:
                element = '<li><a href="?{}">{}</a><li>'.format(query, i)
            page_list.append(element)
        page_string = mark_safe(''.join(page_list))
        return page_string
