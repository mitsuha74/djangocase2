from django.utils.deprecation import MiddlewareMixin
from django.conf import settings
from django.shortcuts import render,redirect,HttpResponse

class AuthMiddleware(MiddlewareMixin):
    def process_request(self,request):
        if request.path_info in ['/login/','/logout/']:
            return
        user_info = request.session.get('user_info')
        if user_info:
            request.unicom_userid = user_info['id']
            request.unicom_username = user_info['username']
            request.unicom_role = user_info['role']
            return
        return redirect('/login/')

    def process_view(self,request,view_func,args,kwargs):
        if request.path_info in ['/login/','/logout/']:
            return
        role = request.unicom_role
        user_permission_set = settings.UNICOM_PERMISSION[role]
        if request.resolver_match.url_name in user_permission_set:
            return
        return HttpResponse('无权访问')

    def process_response(self,request,response):
        return response
